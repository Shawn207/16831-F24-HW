## Reproduce
All commands can be found in hw2_submission but for plot of 7.2.4:
Go to ${rob831}/scripts/, run
```
chmod +x ./run.sh
```
then do: 
```
bash run.sh
```
This will reproduce the 9 curves in plots
